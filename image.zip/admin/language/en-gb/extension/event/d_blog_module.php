<?php 

$_['text_blog']                      = 'Blog';
$_['text_blog_post']                 = 'Posts';
$_['text_blog_category']             = 'Categories';
$_['text_blog_review']               = 'Review';
$_['text_blog_author']               = 'Author';
$_['text_blog_author_group']         = 'Author Group';
$_['text_blog_settings']             = 'Settings';