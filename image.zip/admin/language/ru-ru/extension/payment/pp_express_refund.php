<?php
// Heading
$_['heading_title']		   = 'Возврат транзакции';

// Text
$_['text_pp_express']	   = 'PayPal Экспресс-платежи';
$_['text_current_refunds'] = 'Возврат уже выполнен для данной операции. Максимальная сумма возврата  ';
$_['text_refund']		   = 'Возврат';

// Entry
$_['entry_transaction_id'] = 'ID транзакции';
$_['entry_full_refund']	   = 'Полный возврат';
$_['entry_amount']		   = 'Сумма';
$_['entry_message']		   = 'Сообщение';

// Button
$_['button_refund']		   = 'Оформить возврат';

// Error
$_['error_partial_amt']	   = 'Вы должны ввести часть суммы';
$_['error_data']		   = 'Нет данных';

